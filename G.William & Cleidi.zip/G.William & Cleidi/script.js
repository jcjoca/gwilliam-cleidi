
// Contador
const dataInicial = new Date("2021-03-26T00:00:00");
const contador = document.getElementById("contador");
function atualizarTempo() {
    const agora = new Date();
    let anos = agora.getFullYear() - dataInicial.getFullYear();
    let meses = agora.getMonth() - dataInicial.getMonth();
    let dias = agora.getDate() - dataInicial.getDate();

    if (dias < 0) {
        meses -= 1;
        const ultimoMes = new Date(agora.getFullYear(), agora.getMonth(), 0);
        dias += ultimoMes.getDate();
    }

    if (meses < 0) {
        anos -= 1;
        meses += 12;
    }

    const diferenca = agora - dataInicial;
    const totalDias = Math.floor(diferenca / (1000 * 60 * 60 * 24));
    const semanas = Math.floor(totalDias / 7);

    const horas = Math.floor((diferenca / (1000 * 60 * 60)) % 24);
    const minutos = Math.floor((diferenca / (1000 * 60)) % 60);
    const segundos = Math.floor((diferenca / 1000) % 60);

    contador.innerHTML = `
        ${anos} anos, ${meses} meses, ${semanas} semanas, ${dias} dias<br>
        ${horas}h, ${minutos}min, ${segundos}s
    `;
}



setInterval(atualizarTempo, 1000);

// Slideshow
let slideIndex = 0;
const slides = document.querySelectorAll(".slide");

function mostrarSlides() {
    slides.forEach(slide => slide.classList.remove("active"));
    slideIndex = (slideIndex + 1) % slides.length;
    slides[slideIndex].classList.add("active");
}

slides[0].classList.add("active");
setInterval(mostrarSlides, 3000);
